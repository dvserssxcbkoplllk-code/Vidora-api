import os
import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_NAME = "Vidora API"
# Public Invidious instances can change or become unavailable.
# Set INVIDIOUS_INSTANCES in the hosting environment to override this list.
DEFAULT_INSTANCES = [
    "https://inv.nadeko.net",
    "https://invidious.nerdvpn.de",
    "https://invidious.tiekoetter.com",
]
INSTANCES = [
    item.strip().rstrip("/")
    for item in os.getenv("INVIDIOUS_INSTANCES", ",".join(DEFAULT_INSTANCES)).split(",")
    if item.strip()
]

app = FastAPI(
    title=APP_NAME,
    description="API de búsqueda de videos con reproducción mediante el reproductor oficial de YouTube.",
    version="1.0.0",
)

# For production, replace "*" with the exact origins of your Android/web clients.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")


def best_thumbnail(video: dict) -> str | None:
    thumbs = video.get("videoThumbnails") or []
    if not thumbs:
        return None
    # Prefer the largest thumbnail supplied by the provider.
    thumbs = sorted(thumbs, key=lambda x: (x.get("width") or 0) * (x.get("height") or 0), reverse=True)
    return thumbs[0].get("url")


def normalize_video(video: dict) -> dict | None:
    video_id = video.get("videoId")
    if not video_id:
        return None
    return {
        "id": video_id,
        "title": video.get("title") or "Sin título",
        "author": video.get("author") or "Canal desconocido",
        "description": video.get("description") or "",
        "thumbnail": best_thumbnail(video),
        "duration_seconds": video.get("lengthSeconds"),
        "views": video.get("viewCount"),
        "published": video.get("publishedText"),
        "watch_url": f"https://www.youtube.com/watch?v={video_id}",
        "embed_url": f"https://www.youtube-nocookie.com/embed/{video_id}",
        "provider": "YouTube vía Invidious (búsqueda)",
    }



async def provider_search(query: str, page: int, region: str, content_type: str = "video",
                          duration: str | None = None, sort_by: str = "relevance"):
    errors = []
    timeout = httpx.Timeout(15.0, connect=6.0)
    params = {"q": query, "page": page, "type": content_type, "region": region,
              "sort_by": sort_by}
    if duration:
        params["duration"] = duration
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        for base in INSTANCES:
            try:
                response = await client.get(
                    f"{base}/api/v1/search",
                    params=params,
                    headers={"User-Agent": "VidoraAPI/1.1"},
                )
                response.raise_for_status()
                return response.json(), base
            except Exception as exc:
                errors.append(f"{base}: {type(exc).__name__}")
    raise HTTPException(
        status_code=503,
        detail={
            "message": "No se pudo conectar con las instancias de búsqueda. Probá nuevamente o configurá INVIDIOUS_INSTANCES.",
            "errors": errors,
        },
    )


def normalize_search_item(item: dict) -> dict:
    item_type = item.get("type")
    if item_type == "video" or item.get("videoId"):
        return normalize_video(item) or {}
    if item_type == "channel" or item.get("authorId"):
        thumbs = item.get("authorThumbnails") or []
        return {
            "type": "channel",
            "id": item.get("authorId"),
            "title": item.get("author") or "Canal sin nombre",
            "author": item.get("author") or "",
            "description": item.get("description") or "",
            "thumbnail": (thumbs[-1].get("url") if thumbs else None),
            "channel_url": "https://www.youtube.com/channel/" + str(item.get("authorId") or ""),
            "subscribers": item.get("subCount"),
            "video_count": item.get("videoCount"),
        }
    if item_type == "playlist" or item.get("playlistId"):
        return {
            "type": "playlist",
            "id": item.get("playlistId"),
            "title": item.get("title") or "Lista sin título",
            "author": item.get("author") or "",
            "thumbnail": item.get("playlistThumbnail"),
            "video_count": item.get("videoCount"),
            "playlist_url": "https://www.youtube.com/playlist?list=" + str(item.get("playlistId") or ""),
        }
    return {"type": item_type or "other", "title": item.get("title") or ""}


@app.get("/")
async def home():
    return FileResponse("static/index.html")


@app.get("/health")
async def health():
    return {"status": "ok", "service": APP_NAME, "version": "1.0.0"}



@app.get("/api/search")
async def search_videos(
    q: str = Query(..., min_length=1, max_length=150, description="Texto a buscar"),
    page: int = Query(1, ge=1, le=10),
    region: str = Query("AR", min_length=2, max_length=2),
    kind: str = Query("video", pattern="^(video|channel|playlist)$"),
    duration: str | None = Query(None, pattern="^(short|medium|long)$"),
    sort_by: str = Query("relevance", pattern="^(relevance|views|upload_date)$"),
):
    payload, instance = await provider_search(q, page, region.upper(), kind, duration, sort_by)
    results = [normalize_search_item(item) for item in payload]
    results = [item for item in results if item and item.get("id")]
    return {
        "query": q,
        "page": page,
        "kind": kind,
        "count": len(results),
        "provider_instance": instance,
        "results": results,
    }


@app.get("/api/videos/{video_id}")
async def get_video(video_id: str):
    # IDs from YouTube are normally 11 characters. Restrict characters to avoid URL abuse.
    if not video_id or len(video_id) > 32 or not all(c.isalnum() or c in "-_" for c in video_id):
        raise HTTPException(status_code=400, detail="ID de video no válido")
    return {
        "id": video_id,
        "watch_url": f"https://www.youtube.com/watch?v={video_id}",
        "embed_url": f"https://www.youtube-nocookie.com/embed/{video_id}?autoplay=1&playsinline=1",
        "playback": "official_embed",
        "message": "La reproducción se realiza con el reproductor oficial de YouTube y respeta sus restricciones.",
    }



@app.get("/api/trending")
async def trending(
    region: str = Query("AR", min_length=2, max_length=2),
    category: str = Query("default", pattern="^(default|music|gaming|movies)$"),
):
    errors = []
    async with httpx.AsyncClient(timeout=httpx.Timeout(12.0, connect=5.0), follow_redirects=True) as client:
        for base in INSTANCES:
            try:
                response = await client.get(
                    f"{base}/api/v1/trending",
                    params={"region": region.upper(), "type": category},
                    headers={"User-Agent": "VidoraAPI/1.1"},
                )
                response.raise_for_status()
                payload = response.json()
                videos = [normalize_video(item) for item in payload if item.get("videoId")]
                return {"region": region.upper(), "category": category,
                        "count": len(videos), "results": [v for v in videos if v]}
            except Exception as exc:
                errors.append(f"{base}: {type(exc).__name__}")
    raise HTTPException(status_code=503, detail={"message": "Tendencias no disponibles ahora.", "errors": errors})


@app.get("/api/search/suggestions")
async def search_suggestions(q: str = Query(..., min_length=1, max_length=100)):
    errors = []
    async with httpx.AsyncClient(timeout=httpx.Timeout(10.0, connect=5.0), follow_redirects=True) as client:
        for base in INSTANCES:
            try:
                response = await client.get(
                    f"{base}/api/v1/search/suggestions",
                    params={"q": q},
                    headers={"User-Agent": "VidoraAPI/1.1"},
                )
                response.raise_for_status()
                data = response.json()
                return {"query": q, "suggestions": data.get("suggestions", [])}
            except Exception as exc:
                errors.append(f"{base}: {type(exc).__name__}")
    raise HTTPException(status_code=503, detail={"message": "Sugerencias no disponibles.", "errors": errors})
